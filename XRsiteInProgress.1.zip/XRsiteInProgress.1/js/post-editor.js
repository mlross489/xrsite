var editorView    = document.getElementById('view-editor');
var titleInput    = document.getElementById('post-title');
var authorInput   = document.getElementById('post-author');
var categoryInput = document.getElementById('post-category');
var imgInput      = document.getElementById('feature-img');
var doneButton    = document.getElementById('done');

var resultView    = document.getElementById('view-results');
var imgStep       = document.getElementById('feature-img-step');
var fileImg       = document.getElementById('file-img');
var fileName      = document.getElementById('file-name');
var filePost      = document.getElementById('file-post');
var fileCommit    = document.getElementById('file-commit');

// initiate the markdown editor
var editor;
$(function() {
	editor = editormd('editor-md', {
		height  : 640,
		syncScrolling : 'single',
		path    : 'lib/',
		emoji : true,
		htmlDecode : true,
		saveHTMLToTextarea : true,
		toolbarIcons : function() {
			return ['undo', 'redo', '|', 'bold', 'del', 'italic', 'quote', 'uppercase', '|', 'h1', 'h2', 'h3', 'h4', '|', 'list-ul', 'list-ol', 'hr', '|', 'link', 'image', 'code', 'code-block', 'table', 'datetime', 'emoji', 'html-entities', '|', 'watch', 'preview', 'search', 'fullscreen', 'clear'];
		}
	});
});

// show image preview when uploading feature image
function showPreview(input, previewId) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
			if (typeof previewId === 'string') {
				$('#' + previewId).attr('src', e.target.result);
			} else {
				for (var i=0; i<previewId.length; i++) {
					$('#' + previewId[i]).attr('src', e.target.result);
				}
			}
		};
		reader.readAsDataURL(input.files[0]);
	}
}
imgInput.onchange = function() {
	showPreview(this, ['feature-img-preview', 'file-img-preview']);
};

function slugify(text) {
	return text = text.toLowerCase()
		.replace(/\s+/g, '-')
		.replace(/\-\-+/g, '-')
		.replace(/[^\w\-]+/g, '')
		.replace(/^\-+/, '')
		.replace(/\-+$/, '');
}



function scrollUp() {

    function easeFunction(t) {
        return t < 0.5 ? 8 * t * t * t * t : 1 - 8 * (--t) * t * t * t;
    }

    // Returns document.documentElement for Chrome and Safari
    // document.body for rest of the world
    function checkBody() {
        document.documentElement.scrollTop += 1;
        var body = (document.documentElement.scrollTop !== 0) ? document.documentElement : document.body;
        document.documentElement.scrollTop -= 1;
        return body;
    }
	
    var bodyEl = checkBody();
    var start = bodyEl.scrollTop;
    var startTime = Date.now();
    var destination = 300;

    function scroll() {
        var now = Date.now();
        var time = Math.min(1, ((now - startTime) / 1000));
        var timeFunction = easeFunction(time);

        bodyEl.scrollTop = (timeFunction * (destination - start)) + start;
        if (bodyEl.scrollTop === destination) {
            return;
        }
        requestAnimationFrame(scroll);
    }
    scroll();
}

// get values on form submit
