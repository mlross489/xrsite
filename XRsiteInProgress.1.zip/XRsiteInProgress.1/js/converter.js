var results;

(function() {
    var input = document.getElementById( 'file-1' );
    input.addEventListener("change", handleFileSelect, false);

    function handleFileSelect(event) {
        
            var label = input.nextElementSibling,
                labelVal= label.innerHTML;

            var fileName;
            fileName = event.target.value.split( '\\' ).pop();

            if( fileName )
                label.querySelector( 'span' ).innerHTML = fileName;
            else
                label.innerHTML = labelVal;

            input.addEventListener( 'focus', function(){ input.classList.add( 'has-focus' ); });
            input.addEventListener( 'blur', function(){ input.classList.remove( 'has-focus' ); });

        readFileInputEventAsArrayBuffer(event, function(arrayBuffer) {
            mammoth.convertToMarkdown({arrayBuffer: arrayBuffer})
                .then(saveResult)
                .done();
        });
    }
    
    function saveResult(result) {
      results = result.value;
    }

    
    function readFileInputEventAsArrayBuffer(event, callback) {
        var file = event.target.files[0];

        var reader = new FileReader();
        
        reader.onload = function(loadEvent) {
            var arrayBuffer = loadEvent.target.result;
            callback(arrayBuffer);
        };
        
        reader.readAsArrayBuffer(file);
    }

    function escapeHtml(value) {
        return value
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }
})();

 // function displayResult(result) {
 //        document.getElementById("output").innerHTML = result.value;
        
 //        var messageHtml = result.messages.map(function(message) {
 //            return '<li class="' + message.type + '">' + escapeHtml(message.message) + "</li>";
 //        }).join("");
        
 //        document.getElementById("messages").innerHTML = "<ul>" + messageHtml + "</ul>";
 //    }